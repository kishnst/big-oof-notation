import os
import logging
from flask import Flask
from flask_cors import CORS
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key-for-dev-only")

# Enable CORS for Android app integration
CORS(app, resources={r"/api/*": {"origins": "*"}})

# Import and register routes
from routes.api import api_bp
app.register_blueprint(api_bp, url_prefix='/api')

# Import configuration
from config import configure_app
configure_app(app)

# Simple route for root path
@app.route('/')
def index():
    from flask import render_template
    return render_template('index.html')

# Error handlers
@app.errorhandler(404)
def not_found(error):
    from flask import jsonify
    return jsonify({"error": "Resource not found"}), 404

@app.errorhandler(500)
def server_error(error):
    from flask import jsonify
    logger.error(f"Server error: {error}")
    return jsonify({"error": "Internal server error"}), 500

# Initialize the app context
with app.app_context():
    logger.info("Application initialized")
