import os
import logging
import requests
from services.backends.base import BaseImageBackend

logger = logging.getLogger(__name__)

class ExternalAPIBackend(BaseImageBackend):
    """Image processing backend using an external API service"""
    
    def __init__(self, api_url, api_key):
        """
        Initialize the external API backend
        
        Args:
            api_url (str): URL of the external API
            api_key (str): API key for authentication
        """
        self.api_url = api_url
        self.api_key = api_key
        
        if not self.api_url:
            logger.warning("External API URL not configured")
            
        if not self.api_key:
            logger.warning("External API key not configured")
    
    def process(self, file_path, operations=None):
        """
        Process an image using an external API
        
        Args:
            file_path (str): Path to the image file
            operations (dict): Operations to perform
            
        Returns:
            dict: Processing results from the API
        """
        if not os.path.exists(file_path):
            return {"success": False, "error": "File not found"}
            
        if not self.api_url or not self.api_key:
            return {"success": False, "error": "External API not properly configured"}
        
        operations = operations or {}
        
        try:
            # Prepare the files and data for the API request
            with open(file_path, 'rb') as img_file:
                files = {'image': (os.path.basename(file_path), img_file)}
                
                # Prepare headers with API key
                headers = {
                    'X-API-Key': self.api_key
                }
                
                # Make the API request
                response = requests.post(
                    f"{self.api_url}/process",
                    files=files,
                    data=operations,
                    headers=headers
                )
                
                # Check if the request was successful
                if response.status_code == 200:
                    return response.json()
                else:
                    logger.error(f"External API error: {response.status_code} - {response.text}")
                    return {
                        "success": False,
                        "error": f"API Error: {response.status_code}",
                        "message": response.text
                    }
                    
        except requests.RequestException as e:
            logger.error(f"Error calling external API: {str(e)}")
            return {"success": False, "error": str(e)}
        except Exception as e:
            logger.error(f"Unexpected error with external API: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def get_metadata(self, file_path):
        """
        Get image metadata using the external API
        
        Args:
            file_path (str): Path to the image file
            
        Returns:
            dict: Image metadata from the API
        """
        if not os.path.exists(file_path):
            return {"success": False, "error": "File not found"}
            
        if not self.api_url or not self.api_key:
            return {"success": False, "error": "External API not properly configured"}
        
        try:
            # Prepare the files for the API request
            with open(file_path, 'rb') as img_file:
                files = {'image': (os.path.basename(file_path), img_file)}
                
                # Prepare headers with API key
                headers = {
                    'X-API-Key': self.api_key
                }
                
                # Make the API request
                response = requests.post(
                    f"{self.api_url}/metadata",
                    files=files,
                    headers=headers
                )
                
                # Check if the request was successful
                if response.status_code == 200:
                    return response.json()
                else:
                    logger.error(f"External API error: {response.status_code} - {response.text}")
                    return {
                        "success": False,
                        "error": f"API Error: {response.status_code}",
                        "message": response.text
                    }
                    
        except requests.RequestException as e:
            logger.error(f"Error calling external API: {str(e)}")
            return {"success": False, "error": str(e)}
        except Exception as e:
            logger.error(f"Unexpected error with external API: {str(e)}")
            return {"success": False, "error": str(e)}
