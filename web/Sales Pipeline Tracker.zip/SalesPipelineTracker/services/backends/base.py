from abc import ABC, abstractmethod

class BaseImageBackend(ABC):
    """Abstract base class for image processing backends"""
    
    @abstractmethod
    def process(self, file_path, operations=None):
        """
        Process an image with the given operations
        
        Args:
            file_path (str): Path to the image file
            operations (dict): Dictionary of operations to perform
            
        Returns:
            dict: Processing results
        """
        pass
    
    @abstractmethod
    def get_metadata(self, file_path):
        """
        Extract metadata from an image
        
        Args:
            file_path (str): Path to the image file
            
        Returns:
            dict: Image metadata
        """
        pass
