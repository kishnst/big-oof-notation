import os
import logging
from PIL import Image, ExifTags
from services.backends.base import BaseImageBackend

logger = logging.getLogger(__name__)

class PillowBackend(BaseImageBackend):
    """Image processing backend using Pillow (PIL)"""
    
    def process(self, file_path, operations=None):
        """
        Process an image using Pillow
        
        Args:
            file_path (str): Path to the image file
            operations (dict): Operations to perform (resize, rotate, etc.)
            
        Returns:
            dict: Processing results and metadata
        """
        if not os.path.exists(file_path):
            return {"success": False, "error": "File not found"}
            
        operations = operations or {}
        result = {"success": True, "operations_applied": []}
        
        try:
            with Image.open(file_path) as img:
                # Apply resize if specified
                if 'resize' in operations and operations['resize']:
                    width = int(operations['resize'].get('width', img.width))
                    height = int(operations['resize'].get('height', img.height))
                    img = img.resize((width, height), Image.LANCZOS)
                    result["operations_applied"].append("resize")
                
                # Apply rotation if specified
                if 'rotate' in operations and operations['rotate']:
                    angle = float(operations['rotate'])
                    img = img.rotate(angle, expand=True)
                    result["operations_applied"].append("rotate")
                
                # Apply grayscale conversion if specified
                if operations.get('grayscale', False):
                    img = img.convert('L')
                    result["operations_applied"].append("grayscale")
                
                # Save the processed image if requested
                if operations.get('save_result', False):
                    output_path = f"{os.path.splitext(file_path)[0]}_processed{os.path.splitext(file_path)[1]}"
                    img.save(output_path)
                    result["output_path"] = output_path
                
                # Get basic image properties
                result["dimensions"] = {"width": img.width, "height": img.height}
                result["format"] = img.format
                result["mode"] = img.mode
                
                return result
                
        except Exception as e:
            logger.error(f"Error processing image with Pillow: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def get_metadata(self, file_path):
        """
        Extract metadata from an image using Pillow
        
        Args:
            file_path (str): Path to the image file
            
        Returns:
            dict: Image metadata
        """
        if not os.path.exists(file_path):
            return {"success": False, "error": "File not found"}
            
        try:
            with Image.open(file_path) as img:
                metadata = {
                    "success": True,
                    "filename": os.path.basename(file_path),
                    "format": img.format,
                    "mode": img.mode,
                    "size": {
                        "width": img.width,
                        "height": img.height
                    },
                    "file_size_bytes": os.path.getsize(file_path),
                }
                
                # Extract EXIF data if available
                exif_data = {}
                if hasattr(img, '_getexif') and img._getexif():
                    exif = img._getexif()
                    if exif:
                        for tag_id, value in exif.items():
                            # Some EXIF values might be complex objects, convert them to strings
                            if tag_id in ExifTags.TAGS:
                                tag_name = ExifTags.TAGS[tag_id]
                                try:
                                    # Try to get a simple representation of the value
                                    if isinstance(value, bytes):
                                        value = value.decode('utf-8', 'ignore')
                                    exif_data[tag_name] = str(value)
                                except:
                                    # If conversion fails, use a generic string representation
                                    exif_data[tag_name] = "Value present but not displayable"
                
                metadata["exif"] = exif_data
                return metadata
                
        except Exception as e:
            logger.error(f"Error extracting metadata with Pillow: {str(e)}")
            return {"success": False, "error": str(e)}
