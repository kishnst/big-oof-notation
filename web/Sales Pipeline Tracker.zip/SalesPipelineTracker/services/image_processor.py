from services.backends.pillow_backend import PillowBackend
from services.backends.external_api_backend import ExternalAPIBackend
from flask import current_app
import logging

logger = logging.getLogger(__name__)

class ImageProcessor:
    """
    Service for processing images with different backends
    """
    
    def __init__(self, backend_name=None):
        """
        Initialize the image processor with specified backend
        
        Args:
            backend_name (str): Name of the backend to use ('pillow' or 'external_api')
        """
        self.backend_name = backend_name or current_app.config.get('DEFAULT_BACKEND', 'pillow')
        self.backend = self._get_backend(self.backend_name)
        logger.debug(f"Image processor initialized with {self.backend_name} backend")
    
    def _get_backend(self, backend_name):
        """Get the appropriate backend instance based on name"""
        if backend_name == 'pillow':
            return PillowBackend()
        elif backend_name == 'external_api':
            api_url = current_app.config.get('EXTERNAL_API_URL')
            api_key = current_app.config.get('EXTERNAL_API_KEY')
            return ExternalAPIBackend(api_url, api_key)
        else:
            logger.warning(f"Unknown backend {backend_name}, falling back to pillow")
            return PillowBackend()
    
    def process_image(self, file_path, operations=None):
        """
        Process an image using the selected backend
        
        Args:
            file_path (str): Path to the image file
            operations (dict): Operations to perform on the image
            
        Returns:
            dict: Processing results with metadata
        """
        operations = operations or {}
        logger.debug(f"Processing image {file_path} with {self.backend_name} backend")
        
        try:
            return self.backend.process(file_path, operations)
        except Exception as e:
            logger.error(f"Error processing image: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_metadata(self, file_path):
        """
        Extract metadata from an image
        
        Args:
            file_path (str): Path to the image file
            
        Returns:
            dict: Image metadata
        """
        logger.debug(f"Extracting metadata from {file_path}")
        try:
            return self.backend.get_metadata(file_path)
        except Exception as e:
            logger.error(f"Error extracting metadata: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
