import os
import uuid
from werkzeug.utils import secure_filename
from flask import current_app
import logging

logger = logging.getLogger(__name__)

def save_uploaded_file(file):
    """
    Save an uploaded file with a secure filename in the upload folder
    
    Args:
        file: Flask file object from request.files
        
    Returns:
        str: Path to the saved file
    """
    # Generate a unique filename to prevent collisions
    original_filename = secure_filename(file.filename)
    file_extension = os.path.splitext(original_filename)[1]
    unique_filename = f"{uuid.uuid4().hex}{file_extension}"
    
    # Ensure upload folder exists
    upload_folder = current_app.config['UPLOAD_FOLDER']
    if not os.path.exists(upload_folder):
        os.makedirs(upload_folder)
    
    # Save the file
    file_path = os.path.join(upload_folder, unique_filename)
    file.save(file_path)
    
    logger.debug(f"Saved uploaded file {original_filename} as {unique_filename}")
    
    return file_path

def get_file_size(file_path):
    """
    Get the size of a file in bytes
    
    Args:
        file_path (str): Path to the file
        
    Returns:
        int: Size of the file in bytes
    """
    return os.path.getsize(file_path)

def format_file_size(size_bytes):
    """
    Format file size in human-readable format
    
    Args:
        size_bytes (int): Size in bytes
        
    Returns:
        str: Formatted size string (e.g., "1.23 MB")
    """
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024 or unit == 'GB':
            if unit == 'B':
                return f"{size_bytes} {unit}"
            return f"{size_bytes/1024:.2f} {unit}"
        size_bytes /= 1024
