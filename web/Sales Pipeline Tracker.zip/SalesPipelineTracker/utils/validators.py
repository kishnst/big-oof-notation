import os
from flask import current_app
import logging

logger = logging.getLogger(__name__)

def allowed_file(filename):
    """
    Check if a file has an allowed extension
    
    Args:
        filename (str): Name of the file to check
        
    Returns:
        bool: True if the file extension is allowed, False otherwise
    """
    if '.' not in filename:
        return False
    
    ext = filename.rsplit('.', 1)[1].lower()
    allowed = current_app.config.get('ALLOWED_EXTENSIONS', {'jpg', 'jpeg', 'png'})
    
    logger.debug(f"Checking if file extension '{ext}' is allowed. Allowed extensions: {allowed}")
    return ext in allowed

def validate_operations(operations):
    """
    Validate operations requested for image processing
    
    Args:
        operations (dict): Dictionary of operations to validate
        
    Returns:
        tuple: (is_valid, error_message)
    """
    if not isinstance(operations, dict):
        return False, "Operations must be a dictionary"
    
    # Validate resize parameters
    if 'resize' in operations:
        resize = operations['resize']
        if not isinstance(resize, dict):
            return False, "Resize parameter must be a dictionary"
        
        width = resize.get('width')
        height = resize.get('height')
        
        if width and not isinstance(width, (int, str)) or (isinstance(width, str) and not width.isdigit()):
            return False, "Width must be a positive integer"
            
        if height and not isinstance(height, (int, str)) or (isinstance(height, str) and not height.isdigit()):
            return False, "Height must be a positive integer"
    
    # Validate rotate parameter
    if 'rotate' in operations:
        rotate = operations['rotate']
        try:
            float(rotate)
        except (ValueError, TypeError):
            return False, "Rotate value must be a number"
    
    # Validate grayscale parameter
    if 'grayscale' in operations and not isinstance(operations['grayscale'], bool):
        return False, "Grayscale parameter must be a boolean"
    
    # Validate save_result parameter
    if 'save_result' in operations and not isinstance(operations['save_result'], bool):
        return False, "save_result parameter must be a boolean"
    
    return True, None
