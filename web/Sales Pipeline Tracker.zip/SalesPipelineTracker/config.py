import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def configure_app(app):
    """Configure Flask application"""
    
    # Maximum content length for file uploads (10MB by default)
    app.config['MAX_CONTENT_LENGTH'] = int(os.environ.get('MAX_CONTENT_LENGTH', 10 * 1024 * 1024))
    
    # Allowed file extensions
    app.config['ALLOWED_EXTENSIONS'] = {'jpg', 'jpeg', 'png'}
    
    # Temporary upload directory
    app.config['UPLOAD_FOLDER'] = os.environ.get('UPLOAD_FOLDER', '/tmp/flask_uploads')
    
    # Create upload folder if it doesn't exist
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    
    # Default image processing backend
    app.config['DEFAULT_BACKEND'] = os.environ.get('DEFAULT_BACKEND', 'pillow')
    
    # External API settings (if used)
    app.config['EXTERNAL_API_URL'] = os.environ.get('EXTERNAL_API_URL', '')
    app.config['EXTERNAL_API_KEY'] = os.environ.get('EXTERNAL_API_KEY', '')
    
    # Debug mode
    app.config['DEBUG'] = os.environ.get('DEBUG', 'True').lower() == 'true'
    
    return app
