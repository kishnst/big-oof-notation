import os
import logging
from flask import Blueprint, request, jsonify, current_app
from werkzeug.utils import secure_filename
from services.image_processor import ImageProcessor
from utils.validators import allowed_file
from utils.file_handlers import save_uploaded_file

logger = logging.getLogger(__name__)

# Create blueprint
api_bp = Blueprint('api', __name__)

@api_bp.route('/ping', methods=['GET'])
def ping():
    """Simple endpoint to check if API is running"""
    return jsonify({
        "status": "success",
        "message": "API is running"
    })

@api_bp.route('/process', methods=['POST'])
def process_image():
    """
    Process an uploaded image with specified operations
    
    Expected POST data:
    - file: The image file to process
    - backend: Optional backend to use (default: 'pillow')
    - operations: JSON string of operations to apply
    
    Returns:
        JSON with processing results
    """
    # Check if a file was uploaded
    if 'file' not in request.files:
        return jsonify({
            "status": "error",
            "message": "No file part in the request"
        }), 400
        
    file = request.files['file']
    
    # Check if file was selected
    if file.filename == '':
        return jsonify({
            "status": "error",
            "message": "No file selected"
        }), 400
    
    # Validate file type
    if not allowed_file(file.filename):
        return jsonify({
            "status": "error",
            "message": f"File type not allowed. Supported types: {', '.join(current_app.config['ALLOWED_EXTENSIONS'])}"
        }), 400
        
    try:
        # Save the uploaded file
        file_path = save_uploaded_file(file)
        
        # Get the backend to use (or use default)
        backend = request.form.get('backend', current_app.config.get('DEFAULT_BACKEND'))
        
        # Parse operations if provided
        operations = {}
        if 'operations' in request.form:
            import json
            try:
                operations = json.loads(request.form['operations'])
            except json.JSONDecodeError:
                return jsonify({
                    "status": "error",
                    "message": "Invalid operations JSON"
                }), 400
        
        # Initialize the processor with the selected backend
        processor = ImageProcessor(backend)
        
        # Process the image
        result = processor.process_image(file_path, operations)
        
        # Clean up the temporary file if not needed
        if not operations.get('save_result', False):
            try:
                os.remove(file_path)
                logger.debug(f"Temporary file {file_path} removed")
            except Exception as e:
                logger.warning(f"Could not remove temporary file {file_path}: {str(e)}")
        
        # Return the results
        if result.get("success", False):
            return jsonify({
                "status": "success",
                "data": result
            })
        else:
            return jsonify({
                "status": "error",
                "message": result.get("error", "Unknown error during processing")
            }), 500
            
    except Exception as e:
        logger.error(f"Error in process_image: {str(e)}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@api_bp.route('/metadata', methods=['POST'])
def extract_metadata():
    """
    Extract metadata from an uploaded image
    
    Expected POST data:
    - file: The image file to analyze
    - backend: Optional backend to use (default: 'pillow')
    
    Returns:
        JSON with image metadata
    """
    # Check if a file was uploaded
    if 'file' not in request.files:
        return jsonify({
            "status": "error",
            "message": "No file part in the request"
        }), 400
        
    file = request.files['file']
    
    # Check if file was selected
    if file.filename == '':
        return jsonify({
            "status": "error",
            "message": "No file selected"
        }), 400
    
    # Validate file type
    if not allowed_file(file.filename):
        return jsonify({
            "status": "error",
            "message": f"File type not allowed. Supported types: {', '.join(current_app.config['ALLOWED_EXTENSIONS'])}"
        }), 400
        
    try:
        # Save the uploaded file
        file_path = save_uploaded_file(file)
        
        # Get the backend to use (or use default)
        backend = request.form.get('backend', current_app.config.get('DEFAULT_BACKEND'))
        
        # Initialize the processor with the selected backend
        processor = ImageProcessor(backend)
        
        # Extract metadata
        metadata = processor.get_metadata(file_path)
        
        # Clean up the temporary file
        try:
            os.remove(file_path)
            logger.debug(f"Temporary file {file_path} removed")
        except Exception as e:
            logger.warning(f"Could not remove temporary file {file_path}: {str(e)}")
        
        # Return the metadata
        if metadata.get("success", False):
            return jsonify({
                "status": "success",
                "data": metadata
            })
        else:
            return jsonify({
                "status": "error",
                "message": metadata.get("error", "Unknown error extracting metadata")
            }), 500
            
    except Exception as e:
        logger.error(f"Error in extract_metadata: {str(e)}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@api_bp.route('/backends', methods=['GET'])
def list_backends():
    """List available processing backends"""
    return jsonify({
        "status": "success",
        "data": {
            "available_backends": ["pillow", "external_api"],
            "default_backend": current_app.config.get('DEFAULT_BACKEND')
        }
    })
