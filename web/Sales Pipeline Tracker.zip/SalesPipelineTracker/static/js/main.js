document.addEventListener('DOMContentLoaded', function() {
    // Get form elements
    const form = document.getElementById('imageUploadForm');
    const resizeCheck = document.getElementById('resizeCheck');
    const resizeOptions = document.getElementById('resizeOptions');
    const rotateCheck = document.getElementById('rotateCheck');
    const rotateOptions = document.getElementById('rotateOptions');
    const apiResponse = document.getElementById('apiResponse');
    const loadingIndicator = document.getElementById('loadingIndicator');
    
    // Toggle resize options based on checkbox
    resizeCheck.addEventListener('change', function() {
        resizeOptions.style.display = this.checked ? 'block' : 'none';
    });
    
    // Toggle rotate options based on checkbox
    rotateCheck.addEventListener('change', function() {
        rotateOptions.style.display = this.checked ? 'block' : 'none';
    });
    
    // Handle form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Show loading indicator
        loadingIndicator.classList.remove('d-none');
        
        // Get form values
        const fileInput = document.getElementById('imageFile');
        const backendSelect = document.getElementById('backendSelect');
        const resizeWidth = document.getElementById('resizeWidth');
        const resizeHeight = document.getElementById('resizeHeight');
        const rotateAngle = document.getElementById('rotateAngle');
        const grayscaleCheck = document.getElementById('grayscaleCheck');
        const processRadio = document.getElementById('processRadio');
        
        // Validate file input
        if (!fileInput.files || fileInput.files.length === 0) {
            showResponse({
                status: 'error',
                message: 'Please select a file to upload'
            });
            loadingIndicator.classList.add('d-none');
            return;
        }
        
        // Prepare FormData
        const formData = new FormData();
        formData.append('file', fileInput.files[0]);
        formData.append('backend', backendSelect.value);
        
        // Build operations object if processing is selected
        if (processRadio.checked) {
            const operations = {};
            
            // Add resize parameters if checked
            if (resizeCheck.checked) {
                operations.resize = {};
                if (resizeWidth.value) {
                    operations.resize.width = parseInt(resizeWidth.value);
                }
                if (resizeHeight.value) {
                    operations.resize.height = parseInt(resizeHeight.value);
                }
            }
            
            // Add rotate parameter if checked
            if (rotateCheck.checked && rotateAngle.value) {
                operations.rotate = parseFloat(rotateAngle.value);
            }
            
            // Add grayscale parameter if checked
            if (grayscaleCheck.checked) {
                operations.grayscale = true;
            }
            
            // Add operations to form data if any were specified
            if (Object.keys(operations).length > 0) {
                formData.append('operations', JSON.stringify(operations));
            }
        }
        
        // Determine endpoint based on selected action
        const endpoint = processRadio.checked ? '/api/process' : '/api/metadata';
        
        // Make API request
        fetch(endpoint, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            showResponse(data);
            loadingIndicator.classList.add('d-none');
        })
        .catch(error => {
            showResponse({
                status: 'error',
                message: 'API request failed: ' + error.message
            });
            loadingIndicator.classList.add('d-none');
        });
    });
    
    // Function to display API response
    function showResponse(data) {
        apiResponse.textContent = JSON.stringify(data, null, 2);
    }
    
    // Test API connectivity on page load
    fetch('/api/ping')
        .then(response => response.json())
        .then(data => {
            console.log('API status:', data);
        })
        .catch(error => {
            console.error('API connectivity test failed:', error);
        });
});
